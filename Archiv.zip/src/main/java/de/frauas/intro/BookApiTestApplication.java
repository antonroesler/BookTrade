package de.frauas.intro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookApiTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookApiTestApplication.class, args);
	}

}
